package farms4life2016.fileio;

public class ImportConfig extends ConfigBase {
    
    

}
